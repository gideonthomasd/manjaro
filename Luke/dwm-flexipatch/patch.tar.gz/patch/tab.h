static void drawtab(Monitor *m);
static void drawtabs(void);
static void focuswin(const Arg* arg);
static void tabmode(const Arg *arg);

