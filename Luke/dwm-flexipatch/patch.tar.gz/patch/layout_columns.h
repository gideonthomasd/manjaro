static void col(Monitor *);

