static void shiftviewclients(const Arg *arg);

