static void switchcol(const Arg *arg);

