static void managealtbar(Window win, XWindowAttributes *wa);
static void spawnbar();
static void unmanagealtbar(Window w);
static int wmclasscontains(Window win, const char *class, const char *name);

