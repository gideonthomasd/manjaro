#if !BAR_HOLDBAR_PATCH
static void keyrelease(XEvent *e);
#endif // !BAR_HOLDBAR_PATCH
static void combotag(const Arg *arg);
static void comboview(const Arg *arg);

